#!/usr/bin/env python3
from brain_games.games import game


def main():
    return game.is_even()


if __name__ == '__main__':
    main()
